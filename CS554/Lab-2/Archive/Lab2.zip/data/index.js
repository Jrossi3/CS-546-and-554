const apiData = require('./api');

module.exports = {
    api: apiData,
};