const bandsData = require('./bands');
const albumsData = require('./albums');

module.exports = {
  albums: albumsData,
  bands: bandsData
};