const data = require('./userApi');

module.exports = {
  userApi: data
};